import { Component, OnInit } from '@angular/core';
import { FormBuilder,FormGroup, FormControl, Validators  } from '@angular/forms';
import { RegisterService } from '../register.service';


@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  registerForm: FormGroup;
  
  constructor(private registerService: RegisterService, private formBuilder: FormBuilder) {    
    this.registerForm = this.formBuilder.group({
      'tname':['',Validators.required],
      'temail':['',Validators.required],
      'tpassword':['', [Validators.required, Validators.minLength(6)]],
      'tconfpassword':['', [Validators.required, Validators.minLength(6)]]  
    });
   }

  ngOnInit() { 
   
    //console.log(this.registerService.data);
  }
  register(registerForm){
    //this.old_password.setValue('my name is aji')
    // console.log(this.old_password.valid);
    console.log(this.registerForm);
    console.log(this.registerForm.value,"from register component console");
    if(this.registerForm.invalid){
      console.log("validation");
    }
    // if(this.old_password.valid)
    // console.log(this.old_password.value);
    // console.log(this.registerForm);
    // let result = this.registerForm.value;
    // this.name = this.registerForm.value.name;
    // this.email = this.registerForm.value.emails;
    // this.password = this.registerForm.value.password;
    // this.confirm_password = this.registerForm.value.confirm_password;
    // console.log(this.name,this.email,this.password,this.confirm_password);
    this.registerService.register(this.registerForm);
  

  }

  
  

}
