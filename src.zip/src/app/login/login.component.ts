import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder } from '../../../node_modules/@angular/forms';
import { RegisterService } from '../register.service';
import { Router } from '@angular/router'

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  loginform: FormGroup;

  constructor(
    private registerService: RegisterService,
    private formBuilder: FormBuilder
  ) { 
    this.loginform = this.formBuilder.group({
      'temail':"",
      'password':""     
    });
  }

  ngOnInit() {
  }

  loginsubmit(loginform){
    console.log(this.loginform.value);
    this.registerService.loginsubmit(this.loginform);
  }
}
